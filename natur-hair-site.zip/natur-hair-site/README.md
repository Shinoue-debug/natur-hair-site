# Natur'Hair – site statique

## Avant de publier
Dans index.html, section CONFIG (en bas) : mets ton numéro WhatsApp et le prix.

## Déployer sur Render
1. Crée un dépôt GitHub et envoie-y ces fichiers (index.html, assets/, render.yaml).
2. Sur render.com : New > Static Site > choisis ton dépôt.
3. Build Command : laisse vide. Publish Directory : .
4. Clique sur Create Static Site. Ton lien .onrender.com est prêt en 1 à 2 minutes.
